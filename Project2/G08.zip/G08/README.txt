The project has been developed inside the ipynb, so we do not have a separate source file.
Also, in ./dataset.csv there is a materialized copy of the dataset created using the features that has been built inside the notebook.

Sorry if we went a bit out the target number of pages, we tried to be as short as possible but there were too many stuff to write :c
