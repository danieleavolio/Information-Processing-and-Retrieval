The project has been developed inside the ipynb, so we do not have a separate source file.
Also, the dataset.csv is the dataset created by us using the features built inside the notebook